//
//  ViewController.h
//  CustomButtonStyle
//
//  Created by moyekong on 12/29/15.
//  Copyright © 2015 wiwide. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

