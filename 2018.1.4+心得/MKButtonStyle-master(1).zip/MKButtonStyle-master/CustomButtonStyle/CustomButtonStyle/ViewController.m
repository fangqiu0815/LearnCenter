//
//  ViewController.m
//  CustomButtonStyle
//
//  Created by moyekong on 12/29/15.
//  Copyright © 2015 wiwide. All rights reserved.
//

#import "ViewController.h"
#import "UIButton+ImageTitleSpacing.h"

@interface ViewController ()

@property (weak, nonatomic) IBOutlet UIButton *topButton;
@property (weak, nonatomic) IBOutlet UIButton *leftButton;
@property (weak, nonatomic) IBOutlet UIButton *bottomButton;
@property (weak, nonatomic) IBOutlet UIButton *rightButton;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    [self updateUI];
}

- (void)updateUI {
		CGFloat space = 40.0;
	for (int i = 0; i<4; i++) {

		UIButton * btn_money = [UIButton buttonWithType:UIButtonTypeCustom];
		btn_money.titleLabel.font = [UIFont systemFontOfSize:14];
		[btn_money layoutButtonWithEdgeInsetsStyle:MKButtonEdgeInsetsStyleTop
								   imageTitleSpace:space];
		[btn_money setImage:[UIImage imageNamed:@"set"] forState:0];
		[btn_money setTitle:@"收款" forState:0];
		btn_money.frame = CGRectMake(i*85, 0, 100, 100);
		[self.view addSubview:btn_money];
	}
	
//    CGFloat space = 20.0;
//    [self.topButton layoutButtonWithEdgeInsetsStyle:MKButtonEdgeInsetsStyleTop
//                                    imageTitleSpace:space];
//
//    [self.leftButton layoutButtonWithEdgeInsetsStyle:MKButtonEdgeInsetsStyleLeft
//                                     imageTitleSpace:space];
//
//    [self.bottomButton layoutButtonWithEdgeInsetsStyle:MKButtonEdgeInsetsStyleBottom
//                                       imageTitleSpace:space];
//
//    [self.rightButton layoutButtonWithEdgeInsetsStyle:MKButtonEdgeInsetsStyleRight
//                                      imageTitleSpace:space];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
